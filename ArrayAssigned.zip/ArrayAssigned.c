#include <sys/stat.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	int array_1d[10]={2,3,4,5,6,7,8,9,0,1};
	int array_sz , i;
	// check arguments
	if (argc > 1) {
		printf("usage: %s runs without any arguments. \n", argv[0]);
		return 1;
	}

   // get the size of array (total allocated / element size)
	array_sz =  sizeof(array_1d)/sizeof(array_1d[0]);
	for(i=0;i<array_sz;i++)
	{
	//	array_1d[i] = i;
		printf("Element no %d : %d\n" , i , array_1d[i] );
	}
	return 0; // couldn't be any simpler.
}
