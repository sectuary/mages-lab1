#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>

off_t fsize(const char *filename);
int encrypt(const char *filename, const char *keyfname, const char *outfname);


/**
 * Encode using ADD, as the input are char types
 * The carry flag is NOT updated
 */
int encrypt(const char *filename, const char *keyfname, const char *outfname)
{
	FILE *fsrc, *fkey, *fout;

	fsrc = fopen(filename, "rb");
	fkey = fopen(keyfname, "rb");
	fout = fopen(outfname, "wb");
	// printf("msg_len %s  %s  %s\n", filename, keyfname, outfname);
	if (!fsrc || !fkey || !fout) {
		fprintf(stderr, "Cannot open file.\n");
		return 1;
	}
	printf("\nEncrypting ....\n");
	char x, y;
	while ((x = fgetc(fsrc)) != EOF) {
		y = fgetc(fkey);
		if (y == EOF) {
			rewind(fkey);
			y = fgetc(fkey);
		}
		fputc(x + y  , fout);
	}
	printf("Encryption completed\n");
	//fputc(EOF, fout);

	fclose(fsrc);
	fclose(fkey);
	fclose(fout);

	return 0;
}


/* return the file size of a single file */
off_t fsize(const char *filename) {
	struct stat st;

	if (stat(filename, &st) == 0)
		return st.st_size;

	fprintf(stderr, "Cannot determine size of %s: %s\n",
		filename, strerror(errno));
	return -1;
}


int main(int argc, char* argv[])
{
	off_t msg_len;
	int key0_sz, key1_sz, key2_sz, key3_sz, key4_sz, key5_sz, key6_sz;
	time_t rawtime;
	int wkday;
	const char* key_file_use;

	if (argc > 1) {
		printf("usage: %s reads input.txt and write to output.txt", argv[0]);
		return 1;
	}

	msg_len = fsize("input.txt");
	if (msg_len == -1) {
		printf("msg_len %d\n", msg_len);
		return 1;
	}

	key0_sz = fsize("key0");
	key1_sz = fsize("key1");
	key2_sz = fsize("key2");
	key3_sz = fsize("key3");
	key4_sz = fsize("key4");
	key5_sz = fsize("key5");
	key6_sz = fsize("key6");

	time(&rawtime);

	wkday = localtime(&rawtime)->tm_wday;;
//	printf("Current local time and date: %d", wkday);


	switch (wkday){
	case 0:
		key_file_use = "key0";
		break;
	case 1:
		key_file_use = "key1";
		break;
	case 2:
		key_file_use = "key2";
		break;
	case 3:
		key_file_use = "key3";
		break;
	case 4:
		key_file_use = "key4";
		break;
	case 5:
		key_file_use = "key5";
		break;
	case 6:
		key_file_use = "key6";
		break;
	}
	encrypt("input.txt", key_file_use , "output.txt");

	return 0;
}
