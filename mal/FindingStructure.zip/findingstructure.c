#include <string.h>
#include <stdio.h>
#include <errno.h>

#define def_string "user"

char global_array[100]="This is global_array, pre-assignment";
char global_array_2[50];
struct Books {
   char  title[50];
   char  author[50];
};


int main(int argc, char* argv[])
{
 printf("Local array is created here - %s.\n" ,  def_string );
 char local_array[100]="This is local array data";

 struct Books Book1;        /* Declare Book1 of type Book */
 struct Books Book2;        /* Declare Book2 of type Book */
 /* book 1 specification */
 strcpy( Book1.title, "C Programming");
 strcpy( Book1.author, "Nuha Ali");

/* book 2 specification */
   strcpy( Book2.title, "Telecom Billing");
   strcpy( Book2.author, "Zara Ali");

 return 0;
}
